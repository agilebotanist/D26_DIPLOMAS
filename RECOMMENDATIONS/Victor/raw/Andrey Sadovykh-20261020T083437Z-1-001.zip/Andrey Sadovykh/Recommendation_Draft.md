# Optional Recommendation Letter Draft - Professor Andrey Sadovykh

**For use only if helpful.** Please revise freely, delete anything you did not personally observe, add concrete examples, and use your own voice.

To the Admissions Committee,

I am pleased to recommend Viktor Vanichkov for admission to your PhD program. I worked with Viktor at Innopolis University when he served as a Teaching Assistant, which gave me the opportunity to observe his technical preparation, reliability, communication with students, and ability to work independently in an academic environment.

As a Teaching Assistant, Viktor consulted students on coursework and homework, helped them reason through technical problems, and reviewed and graded assignments. He approached these responsibilities seriously and was able to communicate technical material clearly rather than simply provide answers.

[ADD ONE CONCRETE EXAMPLE - a course responsibility he handled independently, a difficult student question, the quality of his feedback, or another situation you personally observed.]

Viktor's strengths include [TECHNICAL DEPTH / ANALYTICAL THINKING / RESPONSIBILITY / COMMUNICATION / INDEPENDENCE - USE ONLY WHAT YOU SUPPORT]. These qualities are relevant not only to teaching but also to doctoral research, where progress depends on the ability to understand complex material, work autonomously, explain ideas clearly, and respond constructively to feedback.

Viktor is now returning to academic research after substantial professional experience in software architecture and technical leadership. His current research focuses on reinforcement learning, heterogeneous embodied agents, and knowledge transfer. He is revising a structured review of heterogeneous federated reinforcement learning and designing a follow-up experimental study of cross-embodiment transferability.

[OPTIONAL, ONLY IF GENUINELY SUPPORTED: Compared with other teaching assistants or students I have worked with, Viktor was particularly strong in ______ / I would place him among the top ___% with respect to ______.]

Based on my experience working with him, I believe Viktor has the technical maturity, independence, and communication skills necessary to succeed in doctoral study. I am pleased to support his application.

Sincerely,

[Professor Andrey Sadovykh]
[Title]
[Institution]
[Email]
