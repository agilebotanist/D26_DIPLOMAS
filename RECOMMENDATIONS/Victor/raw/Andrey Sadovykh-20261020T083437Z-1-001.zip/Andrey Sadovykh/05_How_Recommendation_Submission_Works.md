# Guide for Recommenders — Fall 2027 PhD Applications

**Applicant:** Viktor Vanichkov  
**Programs:** Approximately 14 US PhD applications (Computer Science / ML / Robotics)  
**Requested internal submission date:** **November 25, 2026**

## What you are being asked to do

Provide an **independent and candid academic or professional recommendation** about Viktor's ability to succeed in a research-focused PhD program. The most useful letters give specific examples of work you personally observed and explain what those examples demonstrate about his intellectual ability, independence, technical judgment, research potential, or ability to learn.

## How the submission process works

1. Viktor enters your **preferred email address, name, title, and relationship** in each university's online application portal.
2. **Each university emails you its own secure link** (sometimes with a short questionnaire or ratings form).
3. You upload the recommendation letter directly to the university through that link. The applicant does not normally collect the final confidential letter.
4. You can ordinarily **reuse one general letter for multiple programs**. Universities may ask different brief questions, but there is no expectation of drafting 14 unrelated letters.
5. Viktor tracks invitations, university-specific deadlines, and receipt confirmations. If any invitation fails to arrive, he will resend or contact admissions as necessary.

You may receive approximately **14 invitation emails** if Viktor applies to all programs. Some programs may only issue invitations after the corresponding application is started. Individual deadlines vary, with the earliest applications due **December 1, 2026**; November 25 is a requested buffer, not a university-imposed deadline.

## What to emphasize

Please use the **personalized Recommender Brief** included in your folder, along with the academic CV and Research Concept Note. The brief proposes topics based on how we worked together, **not statements you are required to make**. Specific observations and your authentic assessment matter much more than generic superlatives or rankings.

## Practical writing guidance

- Roughly **one to two pages** is common, but substance matters more than length.
- A reusable salutation such as **“To the Admissions Committee”** is fine.
- Use an institutional letterhead/signature if that is your usual practice, but follow each portal's requirements.
- Do not claim to have directly observed research or accomplishments known only from the attached materials.
- Do not disclose details you are uncomfortable sharing, and do not include anything that would violate confidentiality or NDAs.
- The letter should be written and submitted **under your own independent judgment**. An optional draft is provided separately only if you specifically request one.

## Documents in the folder

**SEND_TO_RECOMMENDER** contains CV, one-page research concept, personalized brief, program/deadline list, and this submission guide, each in Markdown, DOCX, and PDF.

**OPTIONAL_ONLY_IF_DRAFT_REQUESTED** contains an editable suggestion of letter structure. It is not intended for routine distribution or verbatim submission.

Thank you for considering supporting Viktor's application.
