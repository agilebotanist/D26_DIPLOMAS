# Viktor Vanichkov

Innopolis, Republic of Tatarstan, Russia  
+7 987 270 02 44 · v.vanichkov@mftech.pw  
LinkedIn: https://www.linkedin.com/in/viktor-vanichkov/ · GitHub: https://github.com/victorius · Web: https://mftech.pw

## Research Interests
Reinforcement Learning · Multi-Agent Reinforcement Learning · Embodied AI · Robot Learning · Cross-Embodiment Knowledge Transfer

## Education

**Innopolis University**, Innopolis, Russia  
**Doctoral Studies in Computer Science**, 2023–2025  
Research focus: federated reinforcement learning, explainable AI, and autonomous agents in urban environments · Advisor: Adil Khan  
**Competitive 100% Full-Tuition Grant**  
Completed first-semester doctoral coursework and an initial research review on federated reinforcement learning, explainable AI, and autonomous agents.

**Innopolis University**, Innopolis, Russia  
**M.Sc. in Information Technology (Software Engineering)**, 2016–2018  
**Competitive 100% Full-Tuition Grant**  
Industry capstone for KAMAZ: developed and delivered a software system for knowledge assessment/control.

**Kazan National Research Technical University named after A. N. Tupolev (KNRTU-KAI)**, Kazan, Russia  
**M.Sc. in Applied Mathematics and Computer Science**, 2011–2013 · **B.Sc. in Applied Mathematics and Computer Science**, 2007–2011  
Selected quantitative coursework: Probability Theory, Statistics, Functional Analysis, Linear Algebra, Numerical Methods, Optimization Methods, Algorithms and Data Structures.

## Research Experience

**Heterogeneous Federated Reinforcement Learning — Structured Review**, Independent Researcher, 2026–Present
- Surveyed **100+ research papers** across Google Scholar, arXiv, and publisher sources; **67 references are currently included in the manuscript**, with emphasis on recent work and selected foundational studies.
- Developed a **multidimensional taxonomy** linking heterogeneity regimes and dimensions with communicated learning objects, sharing locality, optimization objectives, transferability criteria, algorithmic responses, application domains, and deployment limitations.
- Synthesized cross-paper evidence motivating a shift from universal agent similarity toward **pair-, task-, and transfer-protocol-conditioned transferability**, which forms the research question for a follow-up experimental study.

**Pair-Specific Cross-Embodiment Knowledge Transfer**, Independent Research, 2026–Present
- Formulating a controlled experimental study of directed knowledge transfer between heterogeneous embodied RL agents.
- Designed the study to test whether a reproducible source-target interaction exists after controlling for target trainability and global source usefulness **before** fitting any transferability predictor.
- Designing baselines based on morphology, capabilities, system identification, and behavioral probes, with evaluation on unseen target embodiments and across multiple transfer operators.

**Diginavis / Project Eleven — Product-Project Manager, AI R&D**, 2018–2021
- Led the R&D direction for AI-assisted architectural design under cadastral, geological, and regulatory constraints; guided formulation of residential design as an evolutionary optimization problem using genetic representations of rooms, building elements, furniture, and spatial relationships.
- Directed implementation and experimental validation through a multidisciplinary team of approximately 9 people; analyzed results, identified bottlenecks, and set subsequent algorithmic and research directions.
- Guided distributed/map-reduce execution, constraint-function optimization, and search-space redesign, reducing generation time from **hours to minutes and ultimately seconds**.
- Delivered a working proof of concept capable of generating complete private-house designs, including layout, roof, foundation, electrical systems, water supply, sewage, insolation constraints, and furniture placement.
- Initiated and formulated the subsequent **multi-agent architectural-design research direction**, including the environment/agent concept and experimental agenda.

**Multi-Agent Reinforcement Learning Environment — Personal Research Engineering Project**, 2026–Present
- Designed and developed a custom multi-agent environment in which autonomous agents gather resources, manipulate objects, use abilities, and learn survival-oriented policies in a persistent fantasy-like world.
- Using the environment to iterate on observation, action, reward, and policy design; agent-to-agent communication is planned as a subsequent experimental extension.

## Manuscripts

**Vanichkov, V.** *Heterogeneous Federated Reinforcement Learning: A Structured Review of Heterogeneity, Knowledge Sharing, and Deployment Challenges.* Revised manuscript in preparation.

## Teaching Experience

**Innopolis University — Teaching Assistant**, 2022; 2025–2026
- Master's-level courses: *Management of Software Development* and *Analysis of Software Artifacts*.
- Consulted students, supported coursework/homework, and reviewed and graded assignments.

**College of Information Technologies, KNRTU-KAI — Instructor, Computer Science**, 2011–2013
- Taught cohorts of **35+ students** in introductory computer science, algorithms, data structures, and Java programming.

**KNRTU-KAI — Laboratory Instructor / Teaching Assistant**, 2011–2013
- Conducted C++ programming laboratories and assessed student assignments.

## Selected Professional Experience

**Corporate University of Sberbank — Technical Product Manager / Solution Architect, AI**, 2025–Present
- Own the architecture and technical evolution of an enterprise multi-agent platform supporting **10+ AI agents**, including requirements, backlog, technical validation, orchestration, context/memory, model routing, observability, security controls, and deployment architecture.
- Select and integrate open-source components under legal, security, infrastructure, and business constraints; hands-on experience includes LangChain, LangGraph, LangFlow, MLflow, LiteLLM, Guardrails, Qdrant, PostgreSQL, ClickHouse, RabbitMQ, Prometheus, Grafana, and Loki.

**Moirai Labs — Founder & Technical Lead**, 2025–Present
- Designed and implemented an end-to-end smart-contract analytics platform with Java/Spring and Python services, Kafka, ClickHouse, PostgreSQL, Redis, reporting pipelines, and agent/API layers.

**SORAMITSU — Solution Architect / Senior Technical Project Manager, EVM Direction**, 2021–2025
- Led the EVM product and engineering direction, owning solution design, architecture review, requirements, delivery risk, and technical coordination across DEX, CDP, staking, and cross-chain systems.
- Designed and reviewed the architecture of a cross-chain DEX, including a client-side deployment model enabling autonomous cross-chain swaps while maintaining security across both blockchain networks.
- Led architecture and design for the open-source DEX delivered for the Klaytn ecosystem; later presented the platform and its use cases at Klaymakers23 as a SORAMITSU representative.

**RTC Soft Labs — Senior System Analyst**, 2017–2018
- Contributed architecture, API interactions, requirements, and business-process designs to early releases of Russia's Unified Biometric System.

**EC-Leasing — Software Engineer / Senior Engineer**, 2012–2016
- Developed Java-based enterprise software and automated testing systems; progressed from Junior to Middle to Senior Engineer during tenure.

## Invited Talks & Service

**Invited Talk — “Open Source DEX and Transformative Use Case”**, Klaymakers23, Oct 14, 2023  
Presented the open-source DEX and use cases as a SORAMITSU representative. Video: https://youtube.com/live/Gy5Wjy5ZF5s

**Judge — Klaymakers23 Hackathon**, 2023  
Evaluated hackathon submissions as a SORAMITSU representative and partner representative.

## Technical Skills
**Programming:** Java (advanced), Python, SQL, Solidity  
**ML / RL:** PyTorch, NumPy, pandas, scikit-learn, evolutionary/genetic algorithms  
**Agent / LLM:** LangChain, LangGraph, LangFlow, MLflow, LiteLLM, Guardrails, Qdrant  
**Systems / Data:** Spring Framework, Kafka, RabbitMQ, PostgreSQL, ClickHouse, Redis, Docker, Kubernetes, Prometheus, Grafana, Loki, Linux  
**Languages:** Russian (native), English (C1; TOEFL score pending)
