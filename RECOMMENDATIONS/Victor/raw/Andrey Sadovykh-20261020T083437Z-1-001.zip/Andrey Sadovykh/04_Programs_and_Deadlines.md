# Fall 2027 PhD Programs and Recommendation Deadlines

**Applicant:** Viktor Vanichkov  
**Internal recommender target:** **November 25, 2026**

The internal date is intentionally earlier than the first hard university deadlines so recommenders do not need to manage fourteen separate calendars.

| Program | Application deadline | Recommendation note |
|---|---|---|
| Carnegie Mellon - Machine Learning PhD | Nov 18 early / Dec 9 final | Letters by Dec 9 |
| MIT - EECS PhD | Dec 1 | Use Nov 25 internal target |
| Stanford - Computer Science PhD | Dec 8 | Use Nov 25 internal target |
| UC Berkeley - EECS PhD | Dec 1 | Use Nov 25 internal target |
| UCLA - Computer Science PhD | Dec 15 | Letters by Dec 15 |
| Princeton - Computer Science PhD | Dec 15 | Use Nov 25 internal target |
| UPenn - CIS PhD | Provisionally Dec 15 | Recheck Fall 2027 page |
| UT Austin - Computer Science PhD | Dec 15 | Letters by Dec 20 |
| Michigan - Robotics PhD | Dec 1 | All materials by deadline |
| Cornell - Computer Science PhD | Provisionally Dec 15 | Recheck Fall 2027 page |
| UIUC - Computer Science PhD | Dec 1 | All materials by deadline |
| UMass Amherst - Computer Science PhD | Dec 15 | Use Nov 25 internal target |
| Georgia Tech - Computer Science PhD | Dec 15 | Use Nov 25 internal target |
| Brown - Computer Science PhD | Dec 15 | Deadline includes letters |

**Note:** Cornell and UPenn remain provisional until their Fall 2027 admissions pages are fully updated. Viktor will track all portal statuses and send reminders only if needed.
