# Research Concept Note

**Applicant:** Viktor Vanichkov  
**Target entry:** Fall 2027  
**Status:** Experimental design / research in progress

## Working title
**Does Pair-Specific Transferability Exist? Predicting Directed Cross-Embodiment Knowledge Transfer from Behavioral Probes**

## Research question
Under a fixed transfer protocol, does a reproducible source-target-specific transfer effect remain after controlling for target trainability and global source usefulness? If so, can low-cost behavioral or functional observations predict useful and harmful transfer before expensive target adaptation?

## Core hypotheses
1. **Pair-specific signal exists:** a reproducible source-target interaction remains above experimental noise after controlling for target and source main effects.
2. **Behavioral probes add predictive value:** short standardized interaction trajectories outperform target-only, morphology-only, capability-only, and system-identification baselines on unseen targets.
3. **Transferability depends on the transfer operator:** useful-source rankings change across mechanisms such as full-policy initialization versus representation/backbone transfer.

## Proposed experiment
- Use one controlled robot family, approximately 8-12 embodiments, 2-3 tasks, and 1-2 transfer protocols.
- Train source policies, build a directed source-to-target transfer matrix, and compare transfer against scratch under the same budget.
- Decompose transfer gain into target effect, source effect, pair interaction, and noise.
- Only if the pair interaction is reproducible, fit predictors based on morphology, capabilities, system identification, behavioral probes, and learned behavioral representations.
- Evaluate on held-out target embodiments using ranking, source-selection regret, negative-transfer classification, calibration, confidence intervals, and multiple seeds.

## Research foundation
The study follows *Heterogeneous Federated Reinforcement Learning: A Structured Review of Heterogeneity, Knowledge Sharing, and Deployment Challenges*. The current manuscript surveys 100+ papers and cites 67 works. It develops a multidimensional taxonomy linking heterogeneity regimes/dimensions, communicated learning objects, sharing locality, optimization objectives, transferability criteria, algorithmic responses, application domains, and deployment limitations.

The review is being revised for resubmission. The follow-up study is at the experimental-design stage; implementation and pilot experiments are the next milestones. A negative result would also be useful if source identity contributes little reproducible signal after proper controls.
