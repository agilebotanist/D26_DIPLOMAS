# Recommender Brief - Professor Andrey Sadovykh

**Relationship:** Professor / TA supervisor at Innopolis University  
**Applicant:** Viktor Vanichkov  
**Target entry:** Fall 2027

## Why your perspective is especially valuable
Your letter can provide an independent academic view of Viktor's technical maturity, reliability, communication, and ability to work autonomously in a university environment.

## Academic work you may be able to comment on
Viktor served as a Teaching Assistant at Innopolis University. His TA work included consulting Master's students, helping them reason through coursework and homework, and reviewing and grading assignments. His CV lists TA experience in *Management of Software Development* and *Analysis of Software Artifacts*; please refer only to the course(s) and periods you personally supervised.

## Current direction
Viktor is applying to US PhD programs in reinforcement learning, embodied AI, robot learning, and multi-agent systems. He is currently revising a structured review of heterogeneous federated reinforcement learning and designing a follow-up experimental study of knowledge transfer between heterogeneous embodied agents.

The review surveys 100+ papers, cites 67 works in its current version, and develops a multidimensional taxonomy connecting heterogeneity regimes, knowledge-sharing objects, locality, optimization objectives, transferability, algorithmic responses, application domains, and deployment limitations.

## Points you may be able to comment on
Please use only points you personally observed and genuinely support.
- Technical depth and ability to understand complex material.
- Ability to explain concepts clearly and provide useful feedback to students.
- Reliability and responsibility in academic work.
- Independence and initiative.
- Analytical thinking and problem solving.
- Communication with students and faculty.
- Academic maturity and potential to contribute to a doctoral environment.
- If appropriate, comparative standing relative to other TAs or students you have worked with.

## Most useful form of evidence
Specific examples - a difficult student question, a course responsibility he handled independently, the quality of his feedback, or his reliability over a semester - will be more useful than generic praise.
